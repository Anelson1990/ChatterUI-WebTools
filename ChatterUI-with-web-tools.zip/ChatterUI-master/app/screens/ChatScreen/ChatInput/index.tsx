import MaterialIcons from '@react-native-vector-icons/material-icons/static'
import { randomUUID } from 'expo-crypto'
import { Image } from 'expo-image'
import { launchImageLibraryAsync, requestMediaLibraryPermissionsAsync } from 'expo-image-picker'
import { router } from 'expo-router'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Keyboard, Pressable, TextInput, TouchableOpacity, View } from 'react-native'
import { useMMKVBoolean } from 'react-native-mmkv'
import Animated, {
    BounceIn,
    FadeIn,
    FadeOut,
    LinearTransition,
    ZoomOut,
} from 'react-native-reanimated'
import { create } from 'zustand'
import { useShallow } from 'zustand/react/shallow'

import ThemedButton from '@components/buttons/ThemedButton'
import Alert from '@components/views/Alert'
import { useBottomSheetRef } from '@components/views/BottomSheet'
import CameraSheet from '@components/views/CameraSheet'
import ContextMenu from '@components/views/ContextMenu'
import { XAxisOnlyTransition } from '@lib/animations/transitions'
import { AppSettings } from '@lib/constants/GlobalValues'
import { generateResponse } from '@lib/engine/Inference'
import { useActiveProvider } from '@lib/hooks/ActiveProvider'
import { useUnfocusTextInput } from '@lib/hooks/UnfocusTextInput'
import { Characters } from '@lib/state/Characters'
import { Chats, useInference } from '@lib/state/Chat'
import { useChatInputTextStore } from '@lib/state/components/ChatInput'
import { Logger } from '@lib/state/Logger'
import { Theme } from '@lib/theme/ThemeManager'

import ChatOptions from './ChatInputOptions'

export type Attachment = {
    uri: string
    type: 'image' | 'audio' | 'document'
    name: string
}

const AnimatedTextInput = Animated.createAnimatedComponent(TextInput)

type ChatInputHeightStoreProps = {
    height: number
    setHeight: (n: number) => void
}

export const useInputHeightStore = create<ChatInputHeightStoreProps>()((set) => ({
    height: 54,
    setHeight: (n) => set({ height: Math.ceil(n) }),
}))

const ChatInput = () => {
    const { t } = useTranslation()
    const inputRef = useUnfocusTextInput()
    const { available: activeProvider, mode } = useActiveProvider()
    const { color, borderRadius, spacing } = Theme.useTheme()
    const [sendOnEnter] = useMMKVBoolean(AppSettings.SendOnEnter)
    const [disableSend, setDisableSend] = useState(false)
    const [attachments, setAttachments] = useState<Attachment[]>([])
    const [hideOptions, setHideOptions] = useState(false)
    const cameraSheetRef = useBottomSheetRef()
    const { nowGenerating, abortFunction } = useInference(
        useShallow((state) => ({
            nowGenerating: state.nowGenerating,
            abortFunction: state.abortFunction,
        }))
    )
    const setHeight = useInputHeightStore(useShallow((state) => state.setHeight))

    const { charName } = Characters.useCharacterStore(
        useShallow((state) => ({
            charName: state?.card?.name,
        }))
    )

    const { chatId } = Chats.useChat()

    const { userName } = Characters.useUserStore(
        useShallow((state) => ({ userName: state.card?.name }))
    )

    const { newMessage, setNewMessage } = useChatInputTextStore(
        useShallow((state) => ({
            newMessage: state.text,
            setNewMessage: state.setText,
        }))
    )

    const abortResponse = async () => {
        Logger.info(t('chat.input.errors.abortGeneration'))
        if (abortFunction) await abortFunction()
    }

    const handleSend = async () => {
        Keyboard.dismiss()
        if (!chatId) return
        setDisableSend(true)
        if (newMessage.trim() !== '' || attachments.length > 0)
            Chats.db.mutate.createEntry(
                chatId,
                userName ?? '',
                true,
                newMessage,
                attachments.map((item) => item.uri)
            )
        try {
            const result = await Chats.db.mutate.createEntry(chatId, charName ?? '', false, '')
            setNewMessage('')
            setAttachments([])
            const swipeId = result?.swipes?.[0]?.id
            if (swipeId) generateResponse(swipeId)
        } catch (e) {
            Logger.errorToast(t('chat.input.errors.failedToSend'))
            Logger.error(e)
        } finally {
            setDisableSend(false)
        }
    }

    const handlePickImage = async () => {
        const permissionResult = await requestMediaLibraryPermissionsAsync()

        if (!permissionResult.granted) {
            Alert.alert({
                title: t('common.errors.permissionRequired'),
                description: t('chat.input.errors.permissionDescription'),
                buttons: [
                    {
                        label: t('common.actions.close'),
                    },
                ],
            })
            return
        }

        let result = await launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsMultipleSelection: true,
            aspect: [4, 3],
            quality: 1,
        })

        if (result.canceled) return

        const newAttachments = result.assets
            .map((item) => ({
                uri: item.uri,
                type: 'image',
                name: item.fileName,
            }))
            .filter((item) => !attachments.some((a) => a.name === item.name)) as Attachment[]

        return setAttachments([...attachments, ...newAttachments])
    }

    return (
        <Pressable
            onPress={() => {
                if (activeProvider) return
                if (mode === 'local') {
                    router.push('/screens/ModelManagerScreen')
                } else router.push('/screens/ConnectionsManagerScreen')
            }}
            onLayout={(e) => {
                setHeight(e.nativeEvent.layout.height)
            }}
            disabled={activeProvider}
            style={{
                position: 'absolute',
                width: '98%',
                alignSelf: 'center',
                bottom: 4,
                paddingVertical: spacing.sm,
                paddingHorizontal: spacing.sm,
                backgroundColor: color.neutral._100 + 'cc',
                borderWidth: 1,
                borderColor: color.neutral._200,
                boxShadow: [
                    {
                        offsetX: 1,
                        offsetY: 1,
                        color: color.shadow,
                        spreadDistance: 1,
                        blurRadius: 4,
                    },
                ],
                borderRadius: 16,
                rowGap: spacing.m,
            }}>
            <Animated.FlatList
                itemLayoutAnimation={LinearTransition}
                style={{
                    display: attachments.length > 0 ? 'flex' : 'none',
                    padding: spacing.l,
                    backgroundColor: color.neutral._200,
                    borderRadius: borderRadius.m,
                }}
                horizontal
                contentContainerStyle={{ columnGap: spacing.xl }}
                data={attachments}
                keyExtractor={(item) => item.uri}
                renderItem={({ item }) => {
                    return (
                        <Animated.View
                            entering={BounceIn}
                            exiting={ZoomOut.duration(100)}
                            style={{ alignItems: 'center', rowGap: 8 }}>
                            <Image
                                source={{ uri: item.uri }}
                                style={{
                                    width: 128,
                                    height: undefined,
                                    aspectRatio: 1,
                                    borderRadius: borderRadius.m,
                                    borderWidth: 1,
                                    borderColor: color.primary._500,
                                }}
                            />

                            <ThemedButton
                                iconName="close"
                                iconSize={20}
                                buttonStyle={{
                                    borderWidth: 0,
                                    paddingHorizontal: 2,
                                    paddingVertical: 2,
                                    position: 'absolute',
                                    alignSelf: 'flex-end',
                                    margin: -8,
                                    backgroundColor: color.neutral._500,
                                }}
                                onPress={() => {
                                    setAttachments(attachments.filter((a) => a.uri !== item.uri))
                                }}
                            />
                        </Animated.View>
                    )
                }}
            />
            <CameraSheet
                onTakePicture={(picture) => {
                    setAttachments((attachments) => [
                        ...attachments,
                        {
                            name: randomUUID().toString(),
                            uri: picture.uri,
                            type: 'image',
                        },
                    ])
                }}
                ref={cameraSheetRef}
            />
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    columnGap: spacing.m,
                }}>
                <Animated.View layout={XAxisOnlyTransition}>
                    {!hideOptions && (
                        <Animated.View
                            entering={FadeIn}
                            exiting={FadeOut}
                            style={{
                                flexDirection: 'row',
                                columnGap: 8,
                                alignItems: 'center',
                            }}>
                            <ChatOptions disabled={!activeProvider} />
                            <ContextMenu
                                disabled={!activeProvider}
                                triggerIcon="paper-clip"
                                triggerIconSize={20}
                                buttons={[
                                    {
                                        label: t('chat.input.actions.takePicture'),
                                        icon: 'camera',
                                        onPress: (close) => {
                                            cameraSheetRef.current?.open()
                                            close()
                                        },
                                    },
                                    {
                                        label: t('chat.input.actions.addImage'),
                                        icon: 'picture',
                                        onPress: async (close) => {
                                            close()
                                            handlePickImage()
                                        },
                                    },
                                ]}
                                triggerStyle={{
                                    color: color.text._400,
                                    padding: 6,
                                    backgroundColor: color.neutral._200,
                                    borderRadius: 16,
                                    opacity: activeProvider ? 1 : 0.5,
                                }}
                                placement="top"
                            />
                        </Animated.View>
                    )}
                    {hideOptions && (
                        <Animated.View entering={FadeIn} exiting={FadeOut}>
                            <ThemedButton
                                iconSize={18}
                                iconStyle={{
                                    color: color.text._400,
                                }}
                                buttonStyle={{
                                    padding: 5,
                                    backgroundColor: color.neutral._200,
                                    borderRadius: 32,
                                }}
                                variant="tertiary"
                                iconName="right"
                                onPress={() => setHideOptions(false)}
                            />
                        </Animated.View>
                    )}
                </Animated.View>
                <AnimatedTextInput
                    layout={XAxisOnlyTransition}
                    ref={inputRef}
                    style={{
                        color: color.text._100,
                        backgroundColor: color.neutral._100,
                        flex: 1,
                        borderWidth: 2,
                        borderColor: activeProvider ? color.primary._300 : color.primary._100,
                        borderRadius: borderRadius.l,
                        paddingHorizontal: spacing.m,
                        paddingVertical: spacing.m,
                    }}
                    onPress={() => {
                        setHideOptions(!!newMessage)
                    }}
                    numberOfLines={8}
                    placeholder={
                        activeProvider
                            ? t('chat.input.message')
                            : mode === 'local'
                              ? t('chat.input.noModelLoaded')
                              : t('chat.input.noConnection')
                    }
                    editable={activeProvider}
                    placeholderTextColor={color.text._700}
                    value={newMessage}
                    onChangeText={(text) => {
                        setHideOptions(!!text)
                        setNewMessage(text)
                    }}
                    multiline
                    submitBehavior={sendOnEnter ? 'blurAndSubmit' : 'newline'}
                    onSubmitEditing={sendOnEnter ? handleSend : undefined}
                />
                <Animated.View layout={XAxisOnlyTransition}>
                    <TouchableOpacity
                        disabled={disableSend || !chatId || !activeProvider}
                        style={{
                            borderRadius: borderRadius.m,
                            backgroundColor: !activeProvider
                                ? color.neutral._100
                                : nowGenerating
                                  ? color.error._500
                                  : color.primary._500,
                            padding: spacing.s,
                            borderWidth: 2,
                            borderColor: !activeProvider
                                ? color.primary._100
                                : nowGenerating
                                  ? color.error._500
                                  : color.primary._500,
                        }}
                        onPress={nowGenerating ? abortResponse : handleSend}>
                        <MaterialIcons
                            name={nowGenerating ? 'stop' : 'send'}
                            color={activeProvider ? color.neutral._100 : color.text._700}
                            size={24}
                        />
                    </TouchableOpacity>
                </Animated.View>
            </View>
        </Pressable>
    )
}

export default ChatInput
