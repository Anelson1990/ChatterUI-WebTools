import * as Speech from 'expo-speech'
import { t } from 'i18next'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

import { Storage } from '@lib/enums/Storage'
import { Logger } from '@lib/state/Logger'
import { createMMKVStorage } from '@lib/storage/MMKV'

import { Chats, useInference } from './Chat'

type TTSState = {
    activeSwipeId?: number
    voice?: Speech.Voice
    enabled: boolean
    auto: boolean
    rate: number
    startTTS: (text: string, swipeId: number) => Promise<void>
    stopTTS: () => Promise<void>
    setEnabled: (b: boolean) => void
    setAuto: (b: boolean) => void
    setVoice: (v: Speech.Voice) => void
    setRate: (r: number) => void
    setLiveTTS: (b: boolean) => void

    speak: (text: string, onDone?: () => void, onStop?: () => void) => void
    handleEndGeneration: (swipeId: number, text: string) => Promise<void>
    handleStartGeneration: (swipeId: number) => void
    // stream TTS
    liveTTS: boolean
    pauseLive?: boolean
    setPauseLive: (b: boolean) => void
    buffer: string
    clearAndRunBuffer: (lastIndex: number) => void
    clearBuffer: () => void
    /**
     * Inserts text into the buffer, attempts TTS if valid sentence and adds remainder to buffer
     * @param text text for TTS
     * @returns
     */
    insertBuffer: (text: string) => void
}

const sentenceEndRegex =
    /(?<=[^\d])([。…？！.?!])(?:["'`*_)]*)\s+(?=[A-Z0-9])|([。…？！.?!])(?:["'`*_)]*)$/gm

useInference.subscribe(async ({ nowGenerating }) => {
    const chatId = Chats.useChatState.getState().id

    if (!chatId) return
    const swipe = await Chats.db.query.chatLatestSwipe(chatId)
    if (!swipe) return

    if (!nowGenerating) {
        useTTSStore.getState().handleEndGeneration(swipe.id, swipe.swipe)
    } else {
        useTTSStore.getState().handleStartGeneration(swipe.id)
    }
})

export const useTTSStore = create<TTSState>()(
    persist(
        (set, get) => ({
            voice: undefined,
            enabled: false,
            auto: false,
            liveTTS: false,
            rate: 1,
            activeSwipeId: undefined,
            startTTS: async (text: string, swipeId: number) => {
                const clearIndex = () => {
                    if (get().activeSwipeId === swipeId) set({ activeSwipeId: undefined })
                }

                const currentSpeaker = get().voice

                Logger.info('Starting TTS')
                if (currentSpeaker === undefined) {
                    Logger.errorToast(t('tts.nospeaker'))
                    clearIndex()
                    return
                }
                if (await Speech.isSpeakingAsync()) await Speech.stop()
                const filter = /([。…！？、!?.,*"])/
                const filteredchunks: string[] = []
                const chunks = text.split(filter)
                chunks.forEach((item, index) => {
                    if (!filter.test(item) && item) return filteredchunks.push(item)
                    if (index > 0)
                        filteredchunks[filteredchunks.length - 1] =
                            filteredchunks[filteredchunks.length - 1] + item
                })
                if (filteredchunks.length === 0) filteredchunks.push(text)

                const cleanedchunks = filteredchunks.map((item) =>
                    item.replaceAll(/[*"]/g, '').trim()
                )
                Logger.debug('TTS started with ' + cleanedchunks.length + ' chunks')
                set({ activeSwipeId: swipeId })
                try {
                    cleanedchunks.forEach((chunk, index) =>
                        get().speak(
                            chunk,
                            () => {
                                index === cleanedchunks.length - 1 && clearIndex()
                            },
                            () => clearIndex()
                        )
                    )
                    if (cleanedchunks.length === 0) clearIndex()
                } catch (e) {
                    Logger.error(`Failed to run TTS: ${e}`)
                }
            },
            stopTTS: async () => {
                Logger.info('TTS stopped')
                set({ buffer: '', activeSwipeId: undefined, pauseLive: get().liveTTS })
                await Speech.stop()
            },
            setEnabled: (b: boolean) => {
                set({ enabled: b })
            },
            setAuto: (b: boolean) => {
                set({ auto: b })
            },
            setVoice: (v: Speech.Voice) => {
                set({ voice: v })
            },
            setRate: (r: number) => {
                set({ rate: r })
            },
            setLiveTTS: (b: boolean) => {
                set({ liveTTS: b })
            },
            setPauseLive: (b: boolean) => {
                set({ pauseLive: b })
            },
            speak: (text, onDone = () => {}, onStop = () => {}) => {
                const currentSpeaker = get().voice
                Speech.speak(text, {
                    language: currentSpeaker?.language,
                    voice: currentSpeaker?.identifier,
                    rate: get().rate,
                    onDone: onDone,
                    onStopped: onStop,
                })
            },

            handleEndGeneration: async (swipeId, text) => {
                if (!get().enabled) return
                if (get().liveTTS) {
                    get().clearAndRunBuffer(swipeId)
                } else if (get().auto) {
                    await get().stopTTS()
                    get().startTTS(text, swipeId)
                }
            },

            handleStartGeneration: async (swipeId) => {
                if (get().enabled && get().liveTTS) {
                    await Speech.stop()
                    set({ activeSwipeId: swipeId })
                }
                set({ pauseLive: false })
            },

            // Stream Data

            buffer: '',
            clearAndRunBuffer: (lastIndex) => {
                const buffer = get().buffer

                if (!get().pauseLive && buffer.trim()) {
                    const clean = cleanMarkdown(buffer)
                    if (clean) {
                        set({ activeSwipeId: lastIndex })
                        get().speak(clean, () => set({ activeSwipeId: undefined }))
                    }
                } else {
                    set({ activeSwipeId: undefined })
                }
                set({ buffer: '' })
            },
            clearBuffer: () => {
                set({ buffer: '' })
            },
            insertBuffer: (text: string) => {
                if (!get().enabled || !get().liveTTS || get().pauseLive) return
                const newBuffer = get().buffer + text

                let lastMatchIndex = -1

                while (sentenceEndRegex.exec(newBuffer) !== null) {
                    lastMatchIndex = sentenceEndRegex.lastIndex
                }

                if (lastMatchIndex !== -1) {
                    const fullSentence = newBuffer.slice(0, lastMatchIndex).trim()
                    const remainder = newBuffer.slice(lastMatchIndex)
                    const clean = cleanMarkdown(fullSentence)
                    if (clean) {
                        get().speak(clean)
                    }
                    set({ buffer: remainder })
                } else {
                    set({ buffer: newBuffer })
                }
            },
        }),
        {
            name: Storage.TTS,
            storage: createMMKVStorage(),
            version: 1,
            partialize: (state) => ({
                enabled: state.enabled,
                auto: state.auto,
                voice: state.voice,
                rate: state.rate,
                liveTTS: state.liveTTS,
            }),
        }
    )
)

const cleanMarkdown = (text: string): string => {
    const result = text.replace(/([*_]{1,2}|`|\[\^.*?\]\(.*?\)|<\/?[^>]+>)/g, '')
    return result
}
